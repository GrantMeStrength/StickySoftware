

void CalculateOutlines();
double Get_Outlines_Alt(int i);
double Get_Outlines_Azm(int i);
