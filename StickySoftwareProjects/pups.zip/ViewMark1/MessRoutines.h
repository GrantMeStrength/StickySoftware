
//
// Header for Messier Catalogue objects
//


double Get_Mess_Alt(int i);
double Get_Mess_Azm(int i);
void CalculateMess();
char * Get_Mess_Name(int i);
