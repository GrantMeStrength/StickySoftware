
//
// Header for Const Name routines
//


double Get_CName_Alt(int i);
double Get_CName_Azm(int i);
void CalculateCNames();
char * Get_CName(int i);
