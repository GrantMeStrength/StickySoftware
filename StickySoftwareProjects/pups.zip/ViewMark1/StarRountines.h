//
// Functions to do with stars
//


void CalculateStars(int starlimit);
double Get_Star_Alt(int i);
double Get_Star_Azm(int i);
int Get_Star_Mag(int i);

