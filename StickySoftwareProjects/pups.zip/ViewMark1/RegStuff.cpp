//
// This code creates, stores, retreives and deletes
// information from the registry.
//
// The information stored includes:
// * The current location (lat/long)
// * Various display settings 
//

#include "stdafx.h"
#include "globalstuff.h"

extern bool eastwest;
extern bool northsouth;
extern double local_longitude;
extern double local_latitude;
extern int local_timezone;
extern int local_daylight;

extern bool flags[33];

// Settings used by the auto update feature

extern int CurrentDelay; 
extern int CurrentJump;  
extern int CurrentUnit;
extern int CurrentTarget;
extern int CurrentMags;	

// Location lat,long, tz, dy


void SaveInfo()
{
	HKEY hKey;
	DWORD dwDisp,dwDelay,dwJump,dwUnit,dwTarget,dwMags;
	DWORD dwLat1,dwLat2,dwLong1,dwLong2;
	HRESULT hRes;
	DWORD dwDay,dwZone;
	DWORD dwSettings;
	DWORD dwSettings2;

	dwDay=local_daylight;
	dwZone=local_timezone;

	long int *lip;
	DWORD dw1,dw2;

	lip=(long int *)&local_longitude;
	dw1=*lip++;
	dw2=*lip;
	dwLong1=dw1;dwLong2=dw2;

	lip=(long int *)&local_latitude;
	dw1=*lip++;
	dw2=*lip;
	dwLat1=dw1;dwLat2=dw2;

	dwDelay=CurrentDelay;
	dwJump=CurrentJump;
	dwUnit=CurrentUnit;
	dwTarget=CurrentTarget;
	dwMags=CurrentMags;

	flags[NorthNess]=northsouth;
	flags[EastNess]=eastwest;

	dwSettings=0;
	for (int i=0;i<16;i++)
		if (flags[i]) dwSettings+=1<<i;

	dwSettings2=0;
	for (i=0;i<16;i++)
		if (flags[i+16]) dwSettings2+=1<<i;

	hRes=RegCreateKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Sticky\\PU1",0,NULL,0,KEY_ALL_ACCESS,NULL,&hKey,&dwDisp);

	if (hRes!=ERROR_SUCCESS)
	{
		//MessageBox(NULL,L"CreateKey failed!",L"",MB_OK);
		return;
	}

	hRes=RegSetValueEx(hKey,L"S",0,REG_DWORD,(LPBYTE)&dwSettings,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"S2",0,REG_DWORD,(LPBYTE)&dwSettings2,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"D",0,REG_DWORD,(LPBYTE)&dwDelay,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"J",0,REG_DWORD,(LPBYTE)&dwJump,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"U",0,REG_DWORD,(LPBYTE)&dwUnit,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"T",0,REG_DWORD,(LPBYTE)&dwTarget,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"M",0,REG_DWORD,(LPBYTE)&dwMags,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"La1",0,REG_DWORD,(LPBYTE)&dwLat1,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"La2",0,REG_DWORD,(LPBYTE)&dwLat2,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"Lo1",0,REG_DWORD,(LPBYTE)&dwLong1,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"Lo2",0,REG_DWORD,(LPBYTE)&dwLong2,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"Y",0,REG_DWORD,(LPBYTE)&dwDay,sizeof(DWORD));
	hRes=RegSetValueEx(hKey,L"Z",0,REG_DWORD,(LPBYTE)&dwZone,sizeof(DWORD));

	RegCloseKey(hKey);

}






bool RealLoadInfo()
{
	HKEY hKey;
	DWORD dwSize,dwType;
	DWORD dwSettings,dwSettings2,dwDelay,dwUnit,dwJump,dwTarget,dwMags;
	DWORD dwLat1,dwLat2,dwLong1,dwLong2;
	HRESULT hRes;
	DWORD dwDay,dwZone;



	long int *lip;
	DWORD dw1,dw2;


	hRes=RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Sticky\\PU1",0,KEY_ALL_ACCESS,&hKey);
	if (hRes!=ERROR_SUCCESS)
	{
		//MessageBox(NULL,L"Couldn't open registry!",L"",MB_OK);
		return false;
	}

	dwSize=sizeof(DWORD);
	hRes=RegQueryValueEx(hKey,L"S",0,&dwType,(LPBYTE)&dwSettings,&dwSize);
	if (hRes!=ERROR_SUCCESS)
	{
		//MessageBox(NULL,L"Couldn't read settings registry!",L"",MB_OK);
		RegCloseKey(hKey);
		return false;
	}

	hRes=RegQueryValueEx(hKey,L"S2",0,&dwType,(LPBYTE)&dwSettings2,&dwSize);

	hRes=RegQueryValueEx(hKey,L"D",0,&dwType,(LPBYTE)&dwDelay,&dwSize);
	hRes=RegQueryValueEx(hKey,L"J",0,&dwType,(LPBYTE)&dwJump,&dwSize);
	hRes=RegQueryValueEx(hKey,L"U",0,&dwType,(LPBYTE)&dwUnit,&dwSize);
	hRes=RegQueryValueEx(hKey,L"T",0,&dwType,(LPBYTE)&dwTarget,&dwSize);
	hRes=RegQueryValueEx(hKey,L"M",0,&dwType,(LPBYTE)&dwMags,&dwSize);
	hRes=RegQueryValueEx(hKey,L"La1",0,&dwType,(LPBYTE)&dwLat1,&dwSize);
	hRes=RegQueryValueEx(hKey,L"La2",0,&dwType,(LPBYTE)&dwLat2,&dwSize);
	hRes=RegQueryValueEx(hKey,L"Lo1",0,&dwType,(LPBYTE)&dwLong1,&dwSize);
	hRes=RegQueryValueEx(hKey,L"Lo2",0,&dwType,(LPBYTE)&dwLong2,&dwSize);
	hRes=RegQueryValueEx(hKey,L"Y",0,&dwType,(LPBYTE)&dwDay,&dwSize);
	hRes=RegQueryValueEx(hKey,L"Z",0,&dwType,(LPBYTE)&dwZone,&dwSize);

	RegCloseKey(hKey);

	local_daylight=dwDay;
	local_timezone=dwZone;

	dw1=dwLong1;dw2=dwLong2;
	lip=(long int *) &local_longitude;
	*lip++=dw1;
	*lip=dw2;

	dw1=dwLat1;dw2=dwLat2;
	lip=(long int *) &local_latitude;
	*lip++=dw1;
	*lip=dw2;

	CurrentDelay=dwDelay;
	CurrentJump=dwJump;
	CurrentUnit=dwUnit;
	CurrentTarget=dwTarget;
	CurrentMags=dwMags;

	for (int i=0;i<16;i++)
		if (dwSettings&(1<<i)) flags[i]=true; else flags[i]=false;

	for (i=0;i<16;i++)
		if (dwSettings2&(1<<i)) flags[i+16]=true; else flags[i+16]=false;

	northsouth=flags[NorthNess];
	eastwest=flags[EastNess];

	return true;
}


void DeleteInfo()
// Remove the key
{
	HKEY hKey;
	HRESULT hRes;

	hRes=RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Sticky\\PU1",0,KEY_ALL_ACCESS,&hKey);
	if (hRes!=ERROR_SUCCESS)
	{
		//MessageBox(NULL,L"Couldn't open registry!",L"",MB_OK);
		return;
	}
	/*
	RegDeleteValue(hKey,L"D");
	RegDeleteValue(hKey,L"U");
	RegDeleteValue(hKey,L"J");
	RegDeleteValue(hKey,L"T");
	RegDeleteValue(hKey,L"M");
	RegDeleteValue(hKey,L"La1");
	RegDeleteValue(hKey,L"La2");
	RegDeleteValue(hKey,L"Lo1");
	RegDeleteValue(hKey,L"Lo2");
	RegDeleteValue(hKey,L"Y");
	RegDeleteValue(hKey,L"Z");
	*/
	RegCloseKey(hKey);

	hRes=RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Sticky",0,KEY_ALL_ACCESS,&hKey);
	if (hRes!=ERROR_SUCCESS)
	{
		//MessageBox(NULL,L"Couldn't open registry2!",L"",MB_OK);
		return;
	}


	hRes=RegDeleteKey(HKEY_LOCAL_MACHINE, L"Software\\Sticky\\PU1");
	if (hRes!=ERROR_SUCCESS)
	{
		//MessageBox(NULL,L"Couldn't delete \\s!",L"",MB_OK);
		return;
	}


	RegCloseKey(hKey);

	//MessageBox(NULL,L"deleted!",L"",MB_OK);
}


void LoadInfo()
{


	if (RealLoadInfo()==true) return;

	// The registry setting isn't here, so set all the
	// default values!

flags[GridOn] = true;
flags[HorizonOn] = true;
flags[StarsOn] = true;
flags[PlanetsOn] = true;
flags[SitesOn] = true;
flags[MarkersOn] = true;
flags[LabelsOn] = true;
flags[InvertOn] = false;
flags[TextOn] = true;
flags[MessOn] = false;
flags[ParallaxOn] = false;
flags[HideOn] = true;
flags[SunMoonOn] = true;
flags[OutlineOn] = false;
flags[RealSizeOn] = false;
flags[CompassOn] = false;
flags[TipsOn] = true;
flags[ToolOn] = false;
flags[ToolOpen] = false;

flags[NorthNess]= true;
flags[EastNess]= false;

	local_longitude=5.5; // has to be something to start with...
	local_latitude=54.3;
	local_timezone=0;
	local_daylight=0;

	flags[KeyLook]=true;
	flags[KeyZoom]=false;
	flags[KeyTime]=false;

	eastwest=false;
	northsouth=true;

}