//
// Protypes
//


void LoadInfo();
void SaveInfo();
void DeleteInfo();